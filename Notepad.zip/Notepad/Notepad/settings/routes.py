from flask import jsonify
from . import settings_bp

@settings_bp.route('/settings')
def settings_home():
    return jsonify({'message': 'Settings blueprint home'})
