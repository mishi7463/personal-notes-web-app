# Models for settings blueprint
# Add settings-related models here
