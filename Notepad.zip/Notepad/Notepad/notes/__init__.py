from flask import Blueprint
notes_bp = Blueprint('notes',
                     __name__,
                     template_folder='templates',
                     static_folder='static',
                     static_url_path='/notes/static',
                     url_prefix='/notes')
from . import routes
