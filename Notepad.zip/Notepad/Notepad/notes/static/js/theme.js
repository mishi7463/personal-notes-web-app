function toggleMode() {
    const body = document.body;
    const btn = document.getElementById('toggleModeBtn');

    body.classList.toggle('dark-mode');

    if (body.classList.contains('dark-mode')) {
        btn.textContent = '☀️ Light Mode';
        localStorage.setItem('theme', 'dark');
    } else {
        btn.textContent = '🌙 Dark Mode';
        localStorage.setItem('theme', 'light');
    }
}

window.onload = function() {
    const savedTheme = localStorage.getItem('theme');
    const body = document.body;
    const btn = document.getElementById('toggleModeBtn');

    if (savedTheme === 'dark') {
        body.classList.add('dark-mode');
        btn.textContent = '☀️ Light Mode';
    }
};
