# Models for notes blueprint
# Add note-related models here
