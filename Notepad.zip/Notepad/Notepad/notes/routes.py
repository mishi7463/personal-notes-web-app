from flask import render_template, redirect, url_for, flash, request,\
session, send_file
from . import notes_bp
import MySQLdb
from io import BytesIO
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from ..extensions import mysql
from Notepad.forms import NoteForm
@notes_bp.route('/view')
def main_home():
    user_id = session.get('user_id')
    if not user_id:
        flash("Please login to view your notes.", "warning")
        return redirect(url_for('users.login'))

    q = request.args.get('q', '').strip()
    favorites = request.args.get('favorites', '0').strip()   # 1 = only favorites
    category = request.args.get('category', '').strip()
    pinned = request.args.get('pinned', '0').strip()  

    sql = """
        SELECT id, title, content, category, pinned, favorite, updated_at
        FROM notes
        WHERE user_id = %s AND deleted_at IS NULL
    """
    params = [user_id]

    if category:
        sql += " AND category = %s"
        params.append(category)

    if favorites == "1":
        sql += " AND favorite = 1"
    
    if pinned == "1":
        sql += " AND pinned = 1"

    if q:
        sql += " AND (title LIKE %s OR content LIKE %s OR category LIKE %s)"
        like = f"%{q}%"
        params.extend([like, like, like])

    sql += " ORDER BY pinned DESC, updated_at DESC"

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute(sql, params)
    notes = cur.fetchall()
    cur.close()

    return render_template('notes/home.html', notes=notes)


@notes_bp.route('/add', methods=['GET', 'POST'])
def add_note():
    form = NoteForm()
    if form.validate_on_submit():
        title = form.title.data
        content = form.content.data
        user_id = session.get('user_id')  # assuming user login stores id in session

        if not user_id:
            flash("You must be logged in to add a note.", "warning")
            return redirect(url_for('users.login'))

        cur = mysql.connection.cursor()
        cur.execute("""
            INSERT INTO notes (user_id, title, content, category) 
            VALUES (%s, %s, %s, %s)
        """, (user_id, title, content, form.category.data))
        mysql.connection.commit()
        cur.close()

        flash("Note added successfully!", "success")
        return redirect(url_for('notes.main_home')) 

    return render_template('notes/add_note.html', form=form)

#delete note# Soft delete note (move to trash)
@notes_bp.route('/delete/<int:note_id>')
def delete_note(note_id):
    user_id = session.get('user_id')
    if not user_id:
        flash("Please login first.", "warning")
        return redirect(url_for('users.login'))

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT * FROM notes WHERE id = %s AND user_id = %s", (note_id, user_id))
    note = cur.fetchone()

    if not note:
        flash("Note not found or not yours.", "danger")
        cur.close()
        return redirect(url_for('notes.main_home'))

    # Soft delete: set deleted_at to current timestamp
    cur.execute("UPDATE notes SET deleted_at = NOW() WHERE id = %s AND user_id = %s", (note_id, user_id))
    mysql.connection.commit()
    cur.close()

    flash("Note moved to trash!", "success")
    return redirect(url_for('notes.main_home'))


#edit note
@notes_bp.route('/edit/<int:note_id>', methods=['GET', 'POST'])
def edit_note(note_id):
    user_id = session.get('user_id')
    if not user_id:
        flash("Please login first.", "warning")
        return redirect(url_for('users.login'))

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("SELECT * FROM notes WHERE id = %s AND user_id = %s", (note_id, user_id))
    note = cur.fetchone()

    if not note:
        flash("Note not found or not yours.", "danger")
        cur.close()
        return redirect(url_for('notes.main_home'))

    form = NoteForm(data=note)

    if form.validate_on_submit():
        title = form.title.data
        category = form.category.data
        content = form.content.data

        cur.execute(
            "UPDATE notes SET title = %s, content = %s ,category =%s WHERE id = %s AND user_id = %s",
            (title, content, category,note_id, user_id)
        )
        mysql.connection.commit()
        cur.close()

        flash("Note updated successfully!", "success")
        return redirect(url_for('notes.main_home'))

    cur.close()
    return render_template('notes/edit_note.html', form=form)
# search notes
@notes_bp.route('/search')
def search_notes():
    user_id = session.get('user_id')
    if not user_id:
        return "<p>Please login first.</p>"

    query = request.args.get('q', '').strip()

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)

    # 🔹 Select ALL fields that your template needs
    # (id, title, content, category, updated_at, pinned, favorite)
    base_sql = """
        SELECT id, title, content, category, updated_at, pinned, favorite
        FROM notes
        WHERE user_id = %s and deleted_at is NULL
    """

    if query:
        sql = base_sql + " AND (title LIKE %s OR content LIKE %s) ORDER BY pinned DESC, id DESC"
        cur.execute(sql, (user_id, f"%{query}%", f"%{query}%"))
    else:
        sql = base_sql + " ORDER BY pinned DESC, id DESC"
        cur.execute(sql, (user_id,))

    notes = cur.fetchall()
    cur.close()

    # 🔹 IMPORTANT:
    # Return ONLY the <li> items partial, NOT the whole list+toolbar template
    return render_template('notes/notes.html', notes=notes)

#export notes
@notes_bp.route('/export', methods=['POST'])
def export_notes():
    action = request.form.get('action')
    selected_ids = request.form.getlist('note_ids')

    cur = mysql.connection.cursor()

    if action == 'selected' and selected_ids:
        format_ids = ','.join(selected_ids)
        cur.execute(f"SELECT title, content FROM notes WHERE id IN ({format_ids})")
    else:
        cur.execute("SELECT title, content FROM notes")

    notes = cur.fetchall()
    cur.close()

    if not notes:
        flash("No notes found to export.", "warning")
        return redirect(url_for('notes.view_notes'))

    # Create PDF
    buffer = BytesIO()
    pdf = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4
    y = height - 50

    pdf.setTitle("My Notes Export")
    pdf.setFont("Helvetica-Bold", 16)
    pdf.drawString(50, y, "My Notes")
    pdf.setFont("Helvetica", 12)
    y -= 40

    for title, content in notes:
        if y < 80:  # next page if not enough space
            pdf.showPage()
            y = height - 50
        pdf.drawString(50, y, f"Title: {title}")
        y -= 20
        pdf.drawString(70, y, f"Content: {content}")
        y -= 40

    pdf.save()
    buffer.seek(0)

    return send_file(
        buffer,
        as_attachment=True,
        download_name="notes_export.pdf",
        mimetype='application/pdf'
    )

#Filter Notes 
@notes_bp.route('/filter_notes')
def filter_notes():
    user_id   = session.get('user_id')
    category  = request.args.get('category', '').strip()
    favorites = request.args.get('favorites', '0').strip()  # "1" or "0"

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)

    sql = """
        SELECT id, title, content, category, pinned, favorite, updated_at
        FROM notes
        WHERE user_id = %s and deleted_at is NULL
    """
    params = [user_id]

    # category filter (optional)
    if category:
        sql += " AND category = %s"
        params.append(category)

    # favorites filter (optional)
    if favorites == "1":
        sql += " AND favorite = 1"

    sql += " ORDER BY pinned DESC, updated_at DESC"

    cur.execute(sql, params)
    notes = cur.fetchall()
    cur.close()

    # 🔴 IMPORTANT: yahan JSON nahin, sirf <li> items ka HTML return karna hai
    return render_template("notes/notes.html", notes=notes)


@notes_bp.route('/toggle_pin/<int:note_id>')
def toggle_pin(note_id):
    user_id = session.get('user_id')
    cur = mysql.connection.cursor()
    # toggle pinned
    cur.execute("UPDATE notes SET pinned = NOT pinned WHERE id = %s AND user_id = %s", (note_id, user_id))
    mysql.connection.commit()
    cur.close()
    return {"success": True}

@notes_bp.route('/toggle_fav/<int:note_id>')
def toggle_fav(note_id):
    user_id = session.get('user_id')
    cur = mysql.connection.cursor()
    # toggle favorite
    cur.execute("UPDATE notes SET favorite = NOT favorite WHERE id = %s AND user_id = %s", (note_id, user_id))
    mysql.connection.commit()
    cur.close()
    return {"success": True}

@notes_bp.route('/view_note/<int:note_id>')
def view_note(note_id):
    user_id = session.get('user_id')
    if not user_id:
        flash("Please login to view the note.", "warning")
        return redirect(url_for('users.login'))

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("""
        SELECT id, title, content, category, pinned, favorite, updated_at
        FROM notes
        WHERE id = %s AND user_id = %s
    """, (note_id, user_id))
    note = cur.fetchone()
    cur.close()

    if not note:
        flash("Note not found.", "warning")
        return redirect(url_for('notes.main_home'))

    return render_template('notes/view_note.html', note=note)

#trash route
@notes_bp.route('/trash')
def trash():
    user_id = session.get('user_id')
    if not user_id:
        flash("Please login to view trash.", "warning")
        return redirect(url_for('users.login'))

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cur.execute("""
        SELECT id, title, content, category, updated_at
        FROM notes
        WHERE user_id = %s AND deleted_at IS NOT NULL
        ORDER BY updated_at DESC
    """, (user_id,))
    deleted_notes = cur.fetchall()
    cur.close()

    return render_template('notes/trash.html', notes=deleted_notes)

# Restore note
@notes_bp.route('/trash/restore/<int:note_id>', methods=['POST'])
def restore_note(note_id):
    user_id = session.get('user_id')
    cur = mysql.connection.cursor()
    cur.execute("UPDATE notes SET deleted_at = NULL WHERE id = %s AND user_id = %s", (note_id, user_id))
    mysql.connection.commit()
    cur.close()
    flash("Note restored successfully.", "success")
    return redirect(url_for('notes.trash'))

# Permanently delete note
@notes_bp.route('/trash/delete/<int:note_id>', methods=['POST'])
def delete_note_permanently(note_id):
    user_id = session.get('user_id')
    cur = mysql.connection.cursor()
    cur.execute("DELETE FROM notes WHERE id = %s AND user_id = %s", (note_id, user_id))
    mysql.connection.commit()
    cur.close()
    flash("Note permanently deleted.", "danger")
    return redirect(url_for('notes.trash'))
