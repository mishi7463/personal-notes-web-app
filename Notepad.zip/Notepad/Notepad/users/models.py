# Models for users blueprint
# Add user-related models here
