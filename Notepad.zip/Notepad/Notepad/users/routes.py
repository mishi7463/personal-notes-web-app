from flask import session, render_template, redirect, url_for, flash, request
from werkzeug.security import generate_password_hash , check_password_hash
from ..extensions import mysql
from Notepad.forms import RegisterForm , LoginForm
from . import users_bp 
import MySQLdb
@users_bp.route('/register', methods=['GET', 'POST'])
def register():
    if session.get('user_id'):
        return redirect(url_for('notes.main_home'))  # redirect to your notes page
    form = RegisterForm()
    if form.validate_on_submit():
        username = form.username.data
        email = form.email.data
        password = generate_password_hash(form.password.data)
        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        print(username, email, password)
        # Check if user exists
        cur.execute("SELECT * FROM users WHERE email=%s OR username=%s", (email, username))
        existing_user = cur.fetchone()

        if existing_user:
            flash('User already exists. Try logging in.', 'danger')
        else:
            cur = mysql.connection.cursor()
            cur.execute(
                "INSERT INTO users (username, email, password_hash) VALUES (%s, %s, %s)",
                (username, email, password)
            )
            mysql.connection.commit()  
            cur.close()
            flash("User registered successfully!", "success")
            return redirect(url_for('users.login'))
           

    else:
        if request.method == 'POST':
            print("Form validation failed")
            print(form.errors)
    return render_template('users/register.html', form=form)


@users_bp.route('/login', methods=['GET', 'POST'])
def login():
    if session.get('user_id'):
        return redirect(url_for('notes.main_home'))  # redirect to your notes page
    form = LoginForm()

    if form.validate_on_submit():
        email = form.email.data
        password = form.password.data

        # Check user from DB
        cur = mysql.connection.cursor()
        cur.execute("SELECT id, username, email, password_hash FROM users WHERE email=%s", (email,))
        user = cur.fetchone()
        cur.close()

        if user:
            user_id, username, email, password_hash = user
            if check_password_hash(password_hash, password):
               
                session['user_id'] = user_id
                session['username'] = username
                flash(f"Welcome back, {username}!", "success")
                return redirect(url_for('notes.main_home'))  # redirect to your notes page
            else:
                flash("Incorrect password.", "danger")
        else:
            flash("Email not found.", "danger")

    return render_template('users/login.html', form=form)
@users_bp.route('/logout')
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for('users.login'))

#Profile route
@users_bp.route('/profile', methods=['GET', 'POST'])
def profile():
    user_id = session.get('user_id')
    if not user_id:
        flash("Please login first.", "warning")
        return redirect(url_for('users.login'))

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    # GET: fetch current user info
    cur.execute("SELECT username, email FROM users WHERE id=%s", (user_id,))
    user = cur.fetchone()
    cur.close()

    return render_template('users/profile.html', user=user)

@users_bp.route('/profile/edit', methods=['GET', 'POST'])
def profile_edit():
    user_id = session.get('user_id')
    if not user_id:
        flash("Please login first.", "warning")
        return redirect(url_for('users.login'))

    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)

    # Handle POST for updating info
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        old_password = request.form.get('old_password')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cur.execute("SELECT username, password_hash FROM users WHERE id=%s", (user_id,))
        user = cur.fetchone()
        # Update username
        if username and username != user['username']:
            cur.execute("UPDATE users SET username=%s WHERE id=%s", (username, user_id))
            mysql.connection.commit()
            flash("Profile updated successfully.", "success")
        # Update password if provided
        if old_password and new_password and confirm_password:
            # Check old password
            cur.execute("SELECT password_hash FROM users WHERE id=%s", (user_id,))
            user = cur.fetchone()
            if user and check_password_hash(user['password_hash'] , old_password):  
                if new_password == confirm_password:
                    new_password = generate_password_hash(new_password)
                    cur.execute("UPDATE users SET password_hash=%s WHERE id=%s", (new_password, user_id))
                    mysql.connection.commit()
                    flash("Password updated successfully.", "success")
                else:
                    flash("New password and confirm password do not match.", "danger")
            else:
                flash("Old password is incorrect.", "danger")


        return redirect(url_for('users.profile_edit'))

    # GET: fetch current user info
    cur.execute("SELECT username, email FROM users WHERE id=%s", (user_id,))
    user = cur.fetchone()
    cur.close()

    return render_template('users/profile_edit.html', user=user)

@users_bp.route('/delete_account', methods=['POST'])
def delete_account():
    user_id = session.get('user_id')
    if not user_id:
        flash("Please login first.", "warning")
        return redirect(url_for('users.login'))

    cur = mysql.connection.cursor()

    # Optional: delete all user notes (or move to trash permanently)
    cur.execute("DELETE FROM notes WHERE user_id = %s", (user_id,))

    # Delete user account
    cur.execute("DELETE FROM users WHERE id = %s", (user_id,))

    mysql.connection.commit()
    cur.close()

    # Clear session and log out
    session.clear()
    flash("Your account and all notes have been permanently deleted.", "danger")
    return redirect(url_for('users.login'))
