from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, PasswordField, SubmitField , SelectField
from wtforms.validators import DataRequired, Length, Email, EqualTo

class NoteForm(FlaskForm):
    title = StringField('Title', validators=[DataRequired()])
    content = TextAreaField('Content', validators=[DataRequired()])
    category = SelectField('Category', choices=[
        ('Personal', 'Personal'),
        ('Work', 'Work'),
        ('Study', 'Study'),
        ('Other', 'Other')
    ])
    submit = SubmitField('Save')

class RegisterForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=150)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Register')

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')