from flask import Flask
from .extensions import mysql
# Import Blueprints
from .users import users_bp
from .notes import notes_bp
from .settings import settings_bp
from .main import main_bp

def create_app():
    app = Flask(__name__)
    app.secret_key = 'your_secret_key'
    app.config['MYSQL_HOST'] = 'localhost'
    app.config['MYSQL_USER'] = 'root'
    app.config['MYSQL_PASSWORD'] = ''
    app.config['MYSQL_DB'] = 'mini_notepad'
    mysql.init_app(app) 

    # Register Blueprints
    app.register_blueprint(users_bp)
    app.register_blueprint(notes_bp)
    app.register_blueprint(settings_bp)
    app.register_blueprint(main_bp)
    return app



